DEBUG=False
SAVE_BEST=True
DATA = 'RSR'
pkl_path = 'data/RSR/pathes.pkl'
data_path = 'data/RSR/'
train_start,train_end=0,3000
eval_start,eval_end=3000,3240
threshold=0.995
debug_batch_size=1
lr=2e-4
pre_train_epoch_num=100
epoch_num=700
img_size=(256,256)
ckpt_path='models/RSR/BEST_psnr.ckpt'
# CUDA_VISIBLE_DEVICES="2" python -m torch.distributed.run --nproc_per_node 1 --master_port=29503 train_DDP_H.py