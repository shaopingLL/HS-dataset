import cv2
import numpy as np
import os
import sys
import OpenEXR, Imath
import pickle

os.environ['OPENCV_IO_ENABLE_OPENEXR'] = '1'
def read_exr(filename):
    file = OpenEXR.InputFile(filename)
    header = file.header()
    dw = header['dataWindow']
    size = (dw.max.x - dw.min.x + 1, dw.max.y - dw.min.y + 1)
    pt = Imath.PixelType(Imath.PixelType.FLOAT)
    v_channel = file.channel('V', pt)
    output = np.frombuffer(v_channel, dtype=np.float32)
    output.shape = (size[1], size[0])
    return output


def normalize(vector):
    """Normalize a vector."""
    return vector / np.linalg.norm(vector)

def phong_lighting(albedo, normal, light_position, ambient=(0.1, 0.1, 0.1), diffuse=(1.0,1.0,1.0), specular=(1.0, 1.0, 1.0), shininess=32):
    """
    Calculate Phong lighting model for each pixel.
    
    :param albedo: Albedo image.
    :param normal: Normal map.
    :param light_position: Position of the light source.
    :param ambient: Ambient light intensity.
    :param diffuse: Diffuse reflection intensity.
    :param specular: Specular reflection intensity.
    :param shininess: Exponent determining the size of the specular highlight.
    :return: Image with calculated colors after applying Phong lighting.
    """
    height, width, _ = albedo.shape
    
    # Convert normal map from image format to normalized vectors
    normal_map = normal.astype(np.float32) / 255.0
    normal_map = 2 * normal_map - 1  # Convert from [0, 1] to [-1, 1]
    normal_map = normal
    
    # Initialize output image
    result_image = np.zeros((height, width, 3), dtype=np.float32)
    
    # Light position relative to each pixel
    light_vector = np.tile(normalize(light_position), (height, width, 1))
    
    # Normalize light vector
    # light_vector = normalize(light_vector)
    # import pdb; pdb.set_trace()
    # Normalize normal vectors
    # normal_map = normalize(normal_map)
    
    # Ambient component
    ambient_intensity = ambient * albedo
    
    # Diffuse component
    diffuse_intensity = diffuse * albedo * np.maximum(np.sum(normal_map * light_vector, axis=2, keepdims=True), 0)
    
    # Specular component
    reflect_vector = 2 * (np.sum(normal_map * light_vector, axis=2, keepdims=True)) * normal_map - light_vector
    view_vector = np.tile(np.array([0, 0, -1]), (height, width, 1))  # Assuming camera is looking along the negative Z axis
    specular_intensity = specular * np.power(np.maximum(np.sum(view_vector * reflect_vector, axis=2, keepdims=True), 0), shininess) *255
    
    # Combine components
    # result_image = ambient_intensity + diffuse_intensity + specular_intensity
    result_image = diffuse_intensity + specular_intensity
    # result_image = diffuse_intensity
    # import pdb; pdb.set_trace()
    # Clamp values to [0, 1]
    result_image = np.clip(result_image, 0, 255)
    
    return result_image
for shininess in range(0,34,2):

    index = 57
    pkl_path = '/media/ubuntu3/data3/LIHongzhen_2023/DATA/HG_cycle_V2/pathes_cam_0_human_0-900_no_edge.pkl'
    data_path = '/media/ubuntu3/data3/LIHongzhen_2023/DATA/HG_cycle_V2/'
    with open(pkl_path, 'rb') as file:
        loaded_list = pickle.load(file)
    item = loaded_list[8000+index]

    gt_albedo_path = os.path.join(data_path, item['Albedo_path'])
    gt_normal_path = os.path.join(data_path, item['Normal_path'])
    albedo = cv2.imread(gt_albedo_path)
    normal_cv = cv2.imread(gt_normal_path, cv2.IMREAD_UNCHANGED)
    normal = np.zeros(normal_cv.shape, dtype=np.float32)
    normal[:,:,0] = normal_cv[:,:,2]
    normal[:,:,1] = normal_cv[:,:,1]
    normal[:,:,2] = normal_cv[:,:,0]

    light_position = np.array([10, 10, 15])  # Light position
    # shininess = 8  # Shininess coefficient
    result = phong_lighting(albedo, normal, light_position,shininess=shininess)
    cv2.imwrite(f'test_{shininess}.png', result)
    print(f'test_{shininess}.png')
    # Example usage:
    # normal = np.array([0, 0, 1])  # Normal vector pointing upwards
    # light_position = np.array([10, 10, 10])  # Light position
    # material_color = np.array([1, 0, 0])  # Red material
    # result = phong_lighting(normal, light_position, albedo)

    # print("Final color:", result)
result = phong_lighting(albedo, normal, light_position,shininess=1000)
cv2.imwrite(f'lambertian.png', result)