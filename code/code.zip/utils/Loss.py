import torch.nn as nn
import torch
import cv2
import torch.nn.functional as F
import numpy as np
from utils.vgg_loss import VGGLoss,TVLoss

def rgb_to_gray(images):
    r, g, b = images[:, 0:1, :, :], images[:, 1:2, :, :], images[:, 2:3, :, :]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
    return gray

def compute_image_gradient(image):
    image = rgb_to_gray(image)
    # Define convolution kernels for gradient computation
    kernel_x = torch.Tensor([[1, 0, -1],
                             [2, 0, -2],
                             [1, 0, -1]]).unsqueeze(0).unsqueeze(0)

    kernel_y = torch.Tensor([[1, 2, 1],
                             [0, 0, 0],
                             [-1, -2, -1]]).unsqueeze(0).unsqueeze(0)

    # Make sure kernels are on the same device as the image
    kernel_x = kernel_x.to(image.device)
    kernel_y = kernel_y.to(image.device)

    # Compute gradients
    grad_x = F.conv2d(image, kernel_x, padding=1)
    grad_y = F.conv2d(image, kernel_y, padding=1)

    # Combine gradients in x and y direction
    eps = 1e-12
    gradient = torch.sqrt(grad_x**2 + grad_y**2 + eps)
    # gradient = grad_x**2 + grad_y**2
    return gradient

def multi_scale(input):
    # 多尺度loss计算
    pooling = nn.AvgPool2d(kernel_size=2, stride=2)
    scale_0 = 255 - input
    # scale_1,scale_1_co = pooling(input),pooling(input).repeat_interleave(2,dim=2).repeat_interleave(2,dim=3)
    scale_1 = pooling(scale_0)
    scale_2 = pooling(scale_1)
    scale_3 = pooling(scale_2)
    scale_4 = pooling(scale_3)

    return scale_0, scale_1, scale_2, scale_3, scale_4

def compute_multi_scale_loss(criterion_mse,mse_multi_scale,pred,gt):
    # 多尺度loss计算
    scale_0, scale_1, scale_2, scale_3, scale_4 = multi_scale(pred)
    gt_scale_0, gt_scale_1, gt_scale_2, gt_scale_3, gt_scale_4 = multi_scale(gt)

    w0,w1,w2,w3,w4 = criterion_mse(scale_0, gt_scale_0), criterion_mse(scale_1, gt_scale_1), criterion_mse(scale_2, gt_scale_2), criterion_mse(scale_3, gt_scale_3), criterion_mse(scale_4, gt_scale_4)
    return w0,w1,w2,w3,w4

def compute_multi_scale_loss(criterion_mse,mse_multi_scale,pred,gt):
    # 多尺度loss计算
    scale_0, scale_1, scale_2, scale_3, scale_4 = multi_scale(pred)
    gt_scale_0, gt_scale_1, gt_scale_2, gt_scale_3, gt_scale_4 = multi_scale(gt)

    w0,w1,w2,w3,w4 = criterion_mse(scale_0, gt_scale_0), criterion_mse(scale_1, gt_scale_1), criterion_mse(scale_2, gt_scale_2), criterion_mse(scale_3, gt_scale_3), criterion_mse(scale_4, gt_scale_4)
    return w0,w1,w2,w3,w4

def frame_loss(Geom_Shadow,gt,pred,criterion_mse,crit_vgg,crit_tv,VGG,TV):
    batch_size = gt.shape[0]
    frame_loss = 0
    frame_indices = []
    for i in range(batch_size):
        indices = torch.where(Geom_Shadow[i,0,:,:]<0.5)
        y_max,y_min = indices[0].max(),indices[0].min()
        x_max,x_min = indices[1].max(),indices[1].min()
        pred_frame = pred[i:i+1,0:3,y_min:y_max,x_min:x_max]
        gt_frame = gt[i:i+1,0:3,y_min:y_max,x_min:x_max]
        mse_loss,vgg_loss_value,tv_loss_value = criterion_mse(gt_frame,pred_frame),crit_vgg(pred_frame,gt_frame),crit_tv(pred_frame)*20
        loss = (mse_loss + vgg_loss_value + (tv_loss_value if TV else 0)) if VGG else (mse_loss + (tv_loss_value if TV else 0))
        frame_loss = frame_loss + loss
        frame_indices.append([y_min,y_max,x_min,x_max])
    frame_loss = frame_loss/batch_size
    return frame_loss,frame_indices

def draw_rectangle(img,y_min,y_max,x_min,x_max,edge_color):
    
    img[:,y_min:y_max,x_min] = edge_color
    img[:,y_min:y_max,x_max] = edge_color
    
    img[:,y_min,x_min:x_max] = edge_color
    img[:,y_max,x_min:x_max] = edge_color
    return img

def save_torch_img(img,path):
    img = torch.clamp(img.permute([0,2,3,1]),min=0,max=1)
    img = img.detach().cpu().numpy()
    img = (img*255).astype(np.uint8)
    cv2.imwrite(path,img[0])

def Global_Loss(mse_multi_scale,criterion_mse,pred,RGB_Image,crit_vgg,crit_tv):
    '''
    1.multi_scale_loss:
    2.vgg_loss_value: 
    3.tv_loss_value: 
    4.global_loss:
    '''
    w0,w1,w2,w3,w4 = compute_multi_scale_loss(criterion_mse,mse_multi_scale,pred, RGB_Image)
    multi_scale_loss = w0+w1+w2+w3+w4
    vgg_loss_value = crit_vgg(pred,RGB_Image)
    global_loss = multi_scale_loss + vgg_loss_value
    return global_loss

def Local_Loss(gt,pred,mse_multi_scale,criterion_mse=None,crit_vgg=None,crit_tv=None,VGG=None,TV=None):
    '''
    MSE_MS keep shape, then select top 10% loss as where to compute local_loss
    '''
    local_loss = 0
    MSE_MS =  mse_multi_scale(gt,pred)
    topk = int(MSE_MS.shape[2]*MSE_MS.shape[3]*0.05)
    MSE_MS_flattened = MSE_MS.view(-1, MSE_MS.shape[-3]*MSE_MS.shape[-2]*MSE_MS.shape[-1])
    sorted_loss, _ = torch.topk(MSE_MS_flattened, topk, dim=1)
    local_loss_sum = sorted_loss.sum(dim=1)
    local_loss = (local_loss_sum / topk).mean()
    # local_loss = local_loss_avg.view(batch_size, channels)

    # for i in range(batch_size):
    #     for j in range(channels):
    #         sorted_loss,indices = torch.topk(MSE_MS[i,j,:,:].flatten(),topk,dim=0)
    #         local_loss = local_loss + sorted_loss.sum()/topk
    # local_loss = local_loss/batch_size
    # import pdb;pdb.set_trace()
    return local_loss,0

def Gradient_loss(pred,gt):
    # Compute gradients of predicted and ground-truth images
    pred_grad = compute_image_gradient(pred)
    gt_grad = compute_image_gradient(gt)
    
    # Compute gradient loss
    # grad_loss = F.mse_loss(pred_grad, gt_grad)
    grad_loss,_ = Local_Loss(gt_grad,pred_grad,nn.MSELoss(reduction='none'))
    return grad_loss

def Compute_loss(criterion_mse,crit_vgg,crit_tv,y_3,RGB_Image,regularization_loss,mask_bg):
    '''
    loss = global_loss + local_loss + gan_loss + regularization_loss
    global_loss = mse_loss + vgg_loss + tv_loss
    local_loss = mse_loss
    gan_loss = gan_loss
    '''
    pred = y_3*mask_bg
    RGB_Image = RGB_Image*mask_bg
    mse_multi_scale = nn.MSELoss(reduction='none')
    # import pdb;pdb.set_trace()
    # compute loss
    global_loss = Global_Loss(mse_multi_scale,criterion_mse,pred,RGB_Image,crit_vgg,crit_tv)
    local_loss,local_indices = Local_Loss(gt=RGB_Image,pred=pred,mse_multi_scale=mse_multi_scale)
    grad_loss = Gradient_loss(pred,RGB_Image)
    # loss = global_loss + local_loss  + regularization_loss
    loss = global_loss + local_loss + grad_loss + regularization_loss

    return loss