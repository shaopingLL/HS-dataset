import pickle
from torch.utils.data import DataLoader,Dataset
import cv2
import numpy as np
import torch
import os
import OpenEXR
import Imath
from kornia.geometry.depth import depth_to_normals,depth_to_3d
import warnings
from tqdm import tqdm
# 忽略 DeprecationWarning 警告
warnings.simplefilter("ignore", category=DeprecationWarning)
from math import pi,sin,cos,acos,atan2
from utils.VEC_Shadow import VEC_Shadow
import time
import torch.distributed as dist
import pdb
import torch.nn.functional as F
# 忽略 DeprecationWarning 警告
warnings.simplefilter("ignore", category=DeprecationWarning)

def DOT2Shadow(DOT,num:int,a=1000,b=0.99):
    DOT = a * (DOT - b)
    DOT_S =  1 / (1 + torch.exp(-DOT))
    shadow_mask = DOT_S[:,:,-(num+1):-1].sum(dim=2)/num
    return shadow_mask

def read_exr(filename):
    file = OpenEXR.InputFile(filename)
    header = file.header()
    dw = header['dataWindow']
    size = (dw.max.x - dw.min.x + 1, dw.max.y - dw.min.y + 1)
    pt = Imath.PixelType(Imath.PixelType.FLOAT)
    v_channel = file.channel('V', pt)
    output = np.frombuffer(v_channel, dtype=np.float32)
    output.shape = (size[1], size[0])
    return output

def mask_sample_d(mask,grid_size):
    # 计算新的掩码大小
    rows, cols  = mask.shape
    new_rows = (rows + grid_size - 1) // grid_size
    new_cols = (cols + grid_size - 1) // grid_size
    # 初始化新的掩码
    mask_s = np.zeros((new_rows, new_cols), dtype=int)
    # 遍历每个网格
    for i in range(new_rows):
        for j in range(new_cols):
            # 计算当前网格的边界
            start_row = i * grid_size
            end_row = min(start_row + grid_size, rows)
            start_col = j * grid_size
            end_col = min(start_col + grid_size, cols)
            # 获取当前网格中的所有像素
            grid = mask[start_row:end_row, start_col:end_col]
            # 计算当前网格中值为 1 的像素数量
            # count_ones = np.sum(grid == 255)
            count_ones = torch.sum(grid == 255)
            # 如果超过一半的像素为 1，则将左上角的像素设置为 1
            if count_ones > (grid_size * grid_size) / 2:
                mask_s[i, j] = 1
    mask_return = np.zeros_like(mask)
    mask_return[::grid_size,::grid_size] = mask_s
    mask_return = mask_return[:,:,np.newaxis].repeat(3,axis=2)
    return mask_return

def Get_Shadow(mask_fg_d,mask_bg_d,Depth,intrinsic_matrix,light_direction,cuda,threshold=0.98,index=None):
    x,y,z = light_direction
    h,w = mask_fg_d.shape[0],mask_fg_d.shape[1]
    phi = acos(y)
    theta = atan2(z,x)
    step_y = pi/32
    step_x = step_y/sin(phi)
    angle_list = [[theta,phi,0],[theta+step_x,phi,1],[theta-step_x,phi,2],[theta,phi+step_y,3],[theta,phi-step_y,4]]
    # angle_list = [[theta,phi],[theta,phi],[theta,phi],[theta,phi],[theta,phi]]
    vec_shadow = torch.zeros([5,h,w])
    data_dir = '/media/ubuntu3/data3/LIHongzhen_2023/Light_Stage/vec_shadow/'

    for theta,phi,i in angle_list:
        data_path = data_dir+f'{index}_{i}.npy'
        if os.path.exists(data_path):
            temp = np.load(data_path)
            vec_shadow[i] = torch.from_numpy(temp)
        else:
            light_direction = [sin(phi)*cos(theta),cos(phi),sin(phi)*sin(theta)]
            temp = VEC_Shadow(Depth,intrinsic_matrix,mask_fg_d,mask_bg_d,light_direction,threshold=threshold,cuda=cuda)
            np.save(data_path,temp)
            print(f'generate shadow {index}_{i}.npy')
            vec_shadow[i] = torch.from_numpy(temp)
            cv2.imwrite('shadow.png',(temp*255).astype(np.uint8))
    return vec_shadow

def compute_intrinsic_matrix(h,w,focus,p):
    '''
        计算内参矩阵
        例如计算焦距为80mm,传感器尺寸为36mm,分辨率为512,512的相机
        intrinsic_matrix = compute_intrinsic_matrix(h=512,wh=512,focus=80,p=36)
    '''
    h,w,focus,p = h*1.0,w*1.0,focus*1.0,p*1.0
    dx,dy = p/w,p/h

    intrinsic_matrix = np.zeros((1, 3, 3))
    intrinsic_matrix[:, 0, 0] = focus/dx
    intrinsic_matrix[:, 1, 1] = focus/dx
    intrinsic_matrix[:, 2, 2] = 1.0
    intrinsic_matrix[:, 0, 2] = h/2.0
    intrinsic_matrix[:, 1, 2] = w/2.0
    intrinsic_matrix = torch.from_numpy(intrinsic_matrix)
    return intrinsic_matrix

def np_img_to_torch(np_img):
    torch_img = torch.from_numpy(np_img).permute([2,0,1])
    return torch_img

def render_diffuse_img(albedo,normal,light_direction,ambient_light=0.0):
    # based on input torch format images,render image based on lambertian surface model
    h,w = albedo.shape[1],albedo.shape[2]
    DOT = torch.zeros([1,h,w])
    temp = light_direction.copy()
    temp = torch.tensor(temp)
    temp = temp.unsqueeze(dim=1).unsqueeze(dim=2).repeat(1,h,w)
    DOT = torch.sum(normal*temp,dim=0,keepdim=True)
    DOT = torch.clamp(DOT,min=0,max=1)
    DOT = DOT + ambient_light
    DOT = torch.clamp(DOT,min=0,max=1)
    return DOT

def render_specular_img(albedo,normal,light_direction):
    h,w = albedo.shape[1],albedo.shape[2]
    specular = torch.zeros([4,h,w])
    temp = light_direction.copy()
    temp = torch.tensor(temp)
    temp = temp.unsqueeze(dim=1).unsqueeze(dim=2).repeat(1,h,w)
    dot_nl = (normal*temp).sum(dim=0,keepdim=True)
    R = 2 * dot_nl * normal - temp
    V = torch.tensor([[[0]],[[0]],[[1]]])
    dot_rv = (R*V).sum(dim=0,keepdim=True)
    for i,shininess in enumerate([10,50,150,200]):
        specular[i] = torch.pow(torch.clamp(dot_rv,min=0,max=1),shininess)
    return specular

class MyDataset(Dataset):
    def __init__(self,pkl_path,data_path,start_index,end_index,threshold=0.9985):
        # 初始化数据集
        self.pkl_path = pkl_path
        self.start_index = start_index
        self.end_index = end_index
        self.data_path = data_path
        # 从文件中加载列表
        with open(pkl_path, 'rb') as file:
            loaded_list = pickle.load(file)
        self.data_list = loaded_list[self.start_index:self.end_index]
        print('len of data_list:',len(self.data_list))
        self.threshold = threshold        

    def __len__(self):
        # 返回数据集大小
        return len(self.data_list)

    def __getitem__(self, index):
        # load data from pathes
        data_dict = self.data_list[index] 
        RGB_Path = os.path.join(self.data_path,data_dict['RGB_path'])
        RGB_x_Path = os.path.join(self.data_path,data_dict['RGB_path_x'])
        Albedo_Path = os.path.join(self.data_path,data_dict['Albedo_x_path'])
        # DOT_path = os.path.join(self.data_path,data_dict['DOT_path'])
        DOT_path = os.path.join(self.data_path,data_dict['DOT_s_path'])
        normal_path = os.path.join(self.data_path,data_dict['normal_est_path'])
        Base_color_path = os.path.join(self.data_path,data_dict['Base_color_path'])
        RGB_Image = np_img_to_torch(cv2.imread(RGB_Path))
        Albedo = np_img_to_torch(cv2.imread(Albedo_Path))
        Base_color = np_img_to_torch(cv2.imread(Base_color_path))
        RGB_Image_x = np_img_to_torch(cv2.imread(RGB_x_Path))
        normal = np_img_to_torch(np.load(normal_path))
        light_direction = data_dict['light_direction']
        DOT = torch.load(DOT_path)
        # 计算深度图
        img_dif = torch.ones(Albedo.shape)
        diffuse_shading = render_diffuse_img(normal=normal,albedo=img_dif,light_direction=light_direction)
        specular = render_specular_img(normal=normal,albedo=img_dif,light_direction=light_direction)
        # 读取阴影
        vec_shadow = DOT2Shadow(DOT=DOT,num=9,a=1000,b=self.threshold)
        # 归一化
        RGB_Image = (RGB_Image/255).squeeze(dim=0)       # [3,512,512]
        # RGB_Image = torch.sqrt(RGB_Image)
        RGB_Image_x = (RGB_Image_x/255).squeeze(dim=0)       # [3,512,512]
        # RGB_Image_x = torch.sqrt(RGB_Image_x)
        Albedo = (Albedo/255).squeeze(dim=0)             # [3,512,512]
        Base_color = (Base_color/255).squeeze(dim=0)             # [3,512,512]
        # Albedo = torch.sqrt(Albedo)
        vec_shadow = (vec_shadow).squeeze(dim=0)         # [1,512,512]
        sample_dict = {'RGB_Image':RGB_Image,'RGB_Image_x':RGB_Image_x,'Albedo':Albedo,\
                       'diffuse_shading':diffuse_shading,'Vec_Shadow':vec_shadow.unsqueeze(0),\
                        'light_direction':torch.tensor(light_direction),'specular_shading':specular,\
                        'Base_color':Base_color}
        return sample_dict