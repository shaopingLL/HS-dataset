import cv2
import numpy as np
from numpy import sin,cos,pi
from scipy.integrate import dblquad
import torch

def compute_W(idx,idy):
    f = lambda phi,theta:sin(theta)
    step = pi/16
    # the first parameter is the range of phi
    # the second parameter is the range of theta
    W,error = dblquad(f,idy*step,(idy+1)*step,idx*step,(idx+1)*step)
    return W

def compute_intrinsic_matrix(h,w,focus,p):
    '''
        计算内参矩阵
        例如计算焦距为80mm,传感器尺寸为36mm,分辨率为512,512的相机
        intrinsic_matrix = compute_intrinsic_matrix(h=512,wh=512,focus=80,p=36)
    '''
    h,w,focus,p = h*1.0,w*1.0,focus*1.0,p*1.0
    dx,dy = p/w,p/h

    intrinsic_matrix = np.zeros((1, 3, 3))
    intrinsic_matrix[:, 0, 0] = focus/dx
    intrinsic_matrix[:, 1, 1] = focus/dx
    intrinsic_matrix[:, 2, 2] = 1.0
    intrinsic_matrix[:, 0, 2] = h/2.0
    intrinsic_matrix[:, 1, 2] = w/2.0
    intrinsic_matrix = torch.from_numpy(intrinsic_matrix)
    return intrinsic_matrix

def compute_depth_scale(points_3d):
    h,w = points_3d.shape[2],points_3d.shape[3]
    xx,yy = points_3d[:,0:1,:,:],points_3d[:,1:2,:,:]
    dif_x = (xx[:,:,:,1:w] - xx[:,:,:,0:w-1]) * ((xx[:,:,:,1:w] - xx[:,:,:,0:w-1])>0)
    dif_y = (yy[:,:,1:h,:] - yy[:,:,0:h-1,:]) * ((yy[:,:,1:h,:] - yy[:,:,0:h-1,:])>0)
    depth_scale = 2 /(dif_x.mean()+dif_x.mean())
    return depth_scale

def dilate(img,kernel_size=3,iterations=1):
    kernel = np.ones((kernel_size,kernel_size),np.uint8)
    return cv2.dilate(img,kernel,iterations = iterations)

def erode(img,kernel_size=3,iterations=1):
    kernel = np.ones((kernel_size,kernel_size),np.uint8)
    return cv2.erode(img,kernel,iterations = iterations)

def save_torch_img(img,path):
    img = img[0].detach().cpu().numpy()
    img = np.transpose(img,(1,2,0))
    img = (img*255).astype(np.uint8)
    cv2.imwrite(path,img)

def compute_light_direction(idx,idy):
    phi = (idx-8)*pi/16
    theta = idy*pi/16
    x,z,y = sin(theta)*cos(phi),sin(theta)*sin(phi),cos(theta)
    light_direction = torch.tensor([x,y,z])
    return light_direction