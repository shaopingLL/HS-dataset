from torch import vmap
import torch
import time
import os
import cv2
from kornia.geometry.depth import depth_to_3d
import numpy as np
import random

def compute_intrinsic_matrix(h,w,focus,p):
    '''
        计算内参矩阵
        例如计算焦距为80mm,传感器尺寸为36mm,分辨率为512,512的相机
        intrinsic_matrix = compute_intrinsic_matrix(h=512,wh=512,focus=80,p=36)
    '''
    h,w,focus,p = h*1.0,w*1.0,focus*1.0,p*1.0
    dx,dy = p/w,p/h

    intrinsic_matrix = np.zeros((1, 3, 3))
    intrinsic_matrix[:, 0, 0] = focus/dx
    intrinsic_matrix[:, 1, 1] = focus/dx
    intrinsic_matrix[:, 2, 2] = 1.0
    intrinsic_matrix[:, 0, 2] = h/2.0
    intrinsic_matrix[:, 1, 2] = w/2.0
    intrinsic_matrix = torch.from_numpy(intrinsic_matrix)
    return intrinsic_matrix
def VMAP(points_3d,light_direction,threshold):
    length = points_3d.shape[1]
    light_direction = light_direction.unsqueeze(dim=1).repeat([1,length])
    def vec_shadow(point):
        point = point.unsqueeze(dim=1).repeat([1,length])
        vecs = points_3d - point
        del point
        vecs_3d = vecs / (vecs.norm(dim=0, keepdim=True) + 1e-8)
        del vecs
        vec_distance_3d = (light_direction*vecs_3d).sum(dim=0)
        del vecs_3d
        sorted_values,sorted_indices = torch.sort(vec_distance_3d)
        values = sorted_values[-10:-1]
        del sorted_values,sorted_indices
        value = (values*(values>threshold)).sum()/9
        # mask = (vec_distance_3d>0.988)*(vec_distance_3d<0.99)
        return 1 - value
    return vmap(vec_shadow,in_dims=1,out_dims=0)

def VEC_Shadow(depth, intrinsic_matrix,mask_fg,mask_bg,light_direction,threshold,cuda):
    device = torch.device(f'cuda:{cuda}')
    h,w = mask_fg.shape[0],mask_fg.shape[1]
    points_3d = depth_to_3d(depth=depth.unsqueeze(dim=0),camera_matrix=intrinsic_matrix,normalize_points=True)[0,::]
    points_3d[1,:,:] = -points_3d[1,:,:]
    points_3d[2,:,:] = points_3d[2,:,:].max() - points_3d[2,:,:]
    if mask_fg[0,:,:].sum() > 27000:
        # 选择一个通道（这里选择第一个通道）
        selected_channel = mask_fg[0]
        # 找到所选通道中值为1的坐标
        indices = torch.where(selected_channel == 1)
        num_indices = indices[0].shape[0]
        # 随机采样25000个坐标
        num_samples = 27000
        sampled_indices = random.sample(range(num_indices), num_samples)
        # 获取采样到的值
        sampled_values = selected_channel[indices[0][sampled_indices], indices[1][sampled_indices]]
        # 将结果扩展回原始形状
        mask_fg = torch.zeros_like(mask_fg)  # 创建与原始mask形状相同的张量
        mask_fg[0][indices[0][sampled_indices], indices[1][sampled_indices]] = sampled_values
        mask_fg[1][indices[0][sampled_indices], indices[1][sampled_indices]] = sampled_values
        mask_fg[2][indices[0][sampled_indices], indices[1][sampled_indices]] = sampled_values
    points_3d_flatten = points_3d[torch.from_numpy(mask_fg).permute([2,0,1]).bool()].reshape([3,-1]).float().to(device)
    points_sample_flatten = points_3d[torch.from_numpy(mask_bg).permute([2,0,1]).bool()].reshape([3,-1]).float().to(device)
    L = torch.tensor(light_direction.copy())
    L = L/L.norm(dim=0)
    L = L.to(device)
    func_vmap = VMAP(points_3d_flatten,L,threshold)
    dot = func_vmap(points_sample_flatten)
    del func_vmap
    RESULT = mask_bg[:,:,0].copy()*1.0
    RESULT[mask_bg[:,:,0]==1] = dot.cpu().numpy()
    # import pdb;pdb.set_trace()
    RESULT = cv2.resize(RESULT[::8,::8], (1296, 966))
    return RESULT

def main():
    os.environ['OPENCV_IO_ENABLE_OPENEXR'] = '1'
    device = torch.device('cuda:0')
    depth = torch.from_numpy(cv2.imread('/home/LIHongzhen_2023/DATA/HG_cycle/Cam_0/index_8/human_0/Depth0.exr',cv2.IMREAD_UNCHANGED)[:,:,0]).unsqueeze(dim=0).unsqueeze(dim=0)
    MASK = (cv2.imread('/home/LIHongzhen_2023/DATA/HG_cycle/Cam_0/index_0/human_0/Mask.png')/255).transpose(2,0,1)
    MASK = torch.from_numpy(MASK)
    # MASK[:,115:160,240:280]  = 0
    # import pdb;pdb.set_trace()
    intrinsic_matrix = compute_intrinsic_matrix(h=512, w=512, focus=50, p=33)
    points_3d = depth_to_3d(depth=depth,camera_matrix=intrinsic_matrix,normalize_points=True)[0,::]
    points_3d[1,:,:] = -points_3d[1,:,:]
    points_3d[2,:,:] = points_3d[2,:,:].max() - points_3d[2,:,:]
    time_start_1 = time.time()
    # points_3d_flatten = points_3d[:,::8,::8].reshape([3,-1]).float().to(device)
    points_3d_flatten = points_3d[MASK.bool()].reshape([3,-1])[:,::4].float().to(device)
    # import pdb;pdb.set_trace()
    points_sample_flatten = points_3d[:,::2,::2].reshape([3,-1]).float().to(device)
    idxs = range(1,16)
    idys = range(1,8)
    # idxs = range(1,3)
    # idys = range(1,3)
    for idx in idxs:
        for idy in idys:
            step = np.pi/16
            # idx,idy = 13-1,6
            theta,phi = idx*step,idy*step
            x,y,z = np.sin(phi)*np.cos(theta),np.cos(phi),np.sin(phi)*np.sin(theta)

            light_direction = torch.tensor([x, y, z]) / torch.norm(torch.tensor([x, y, z]).float())
            light_direction = light_direction.unsqueeze(dim=1).to(device)
            func_vmap = VMAP(points_3d_flatten,light_direction)
            dot = func_vmap(points_sample_flatten)
            RESULT = (dot.reshape(256,256).unsqueeze(dim=2).repeat([1,1,3]).cpu().numpy()*255).astype(np.uint8)
            RESULT = cv2.resize(RESULT, (512, 512))
            # MASK = cv2.imread('/home/LIHongzhen_2023/DATA/HG_cycle/Cam_0/index_8/human_0/Mask.png')/255
            # Albedo = cv2.imread('/home/LIHongzhen_2023/DATA/HG_cycle/Cam_0/index_8/human_0/Albedo0.png')
            # RESULT = RESULT*(1-MASK) + Albedo*MASK
            print(f'idx:{idx}, idy:{idy}')
            cv2.imwrite(f'TEST_IMGS/test_idx{idx}_idy{idy}.png',RESULT)
    time_start_2 = time.time()
    print(f'the running time of the function main is:{round(time_start_2 - time_start_1, 3)} seconds')
if __name__ == '__main__':
    main()
