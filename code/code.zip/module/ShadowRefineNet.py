import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import logging
import numpy as np

class SELayer(nn.Module):
    def __init__(self, channel, reduction=1):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, w, h = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)

def model_structure(model):
    blank = ' '
    print('-' * 90)
    print('|' + ' ' * 11 + 'weight name' + ' ' * 10 + '|' \
          + ' ' * 15 + 'weight shape' + ' ' * 15 + '|' \
          + ' ' * 3 + 'number' + ' ' * 3 + '|')
    print('-' * 90)
    num_para = 0
    type_size = 1  # 如果是浮点数就是4

    for index, (key, w_variable) in enumerate(model.named_parameters()):
        if len(key) <= 30:
            key = key + (30 - len(key)) * blank
        shape = str(w_variable.shape)
        if len(shape) <= 40:
            shape = shape + (40 - len(shape)) * blank
        each_para = 1
        for k in w_variable.shape:
            each_para *= k
        num_para += each_para
        str_num = str(each_para)
        if len(str_num) <= 10:
            str_num = str_num + (10 - len(str_num)) * blank

        print('| {} | {} | {} |'.format(key, shape, str_num))
    print('-' * 90)
    print('The total number of parameters: ' + str(num_para))
    print('The parameters of Model {}: {:4f}M'.format(model._get_name(), num_para * type_size / 1000 / 1000))
    print('-' * 90)

def compute_intrinsic_matrix(h,w,focus,p):
    '''
        计算内参矩阵
        例如计算焦距为80mm,传感器尺寸为36mm,分辨率为512,512的相机
        intrinsic_matrix = compute_intrinsic_matrix(h=512,wh=512,focus=80,p=36)
    '''
    h,w,focus,p = h*1.0,w*1.0,focus*1.0,p*1.0
    dx,dy = p/w,p/h

    intrinsic_matrix = np.zeros((1, 3, 3))
    intrinsic_matrix[:, 0, 0] = focus/dx
    intrinsic_matrix[:, 1, 1] = focus/dx
    intrinsic_matrix[:, 2, 2] = 1.0
    intrinsic_matrix[:, 0, 2] = h/2.0
    intrinsic_matrix[:, 1, 2] = w/2.0
    intrinsic_matrix = torch.from_numpy(intrinsic_matrix)
    return intrinsic_matrix

def get_layer_info(out_channels, activation_func='ReLU'):
    # activation = get_activation(activation_func)
    # norm_layer = get_norm(out_channels, 'Group')
    if activation_func == 'LeakyReLU':
        activation = nn.LeakyReLU(0.2)
    elif activation_func == 'Hardtanh':
        activation = nn.Hardtanh()
    elif activation_func == 'Sigmoid':
        activation = nn.Sigmoid()       
    elif activation_func == 'ReLU':
        activation = nn.ReLU()
    elif activation_func == 'Tanh':
        activation = nn.Tanh()
    elif activation_func == 'Softplus':
        activation = nn.Softplus()
    elif activation_func == 'Softshrink':
        activation = nn.Softshrink()
    elif activation_func == 'Hardshrink':
        activation = nn.Hardshrink()
    else:
        activation = nn.ELU()
        
    
    # if out_channels >= 32:
    #     groups = 32
    # else:
    #     groups = 1
    # norm_layer =  nn.GroupNorm(groups, out_channels)
    norm_layer =  nn.GroupNorm(1, out_channels)
    return norm_layer, activation

class Conv(nn.Module):
    """ (convolution => [BN] => ReLU) """
    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size=3,
                 stride=1,
                 padding=1,
                 bias=True,
                 activation='leaky',
                 resnet=True):
        super().__init__()

        norm_layer, act_func = get_layer_info(out_channels,activation)

        if resnet and in_channels == out_channels:
            self.resnet = True
        else:
            self.resnet = False

        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, stride=stride, kernel_size=kernel_size, padding=padding, bias=bias),
            norm_layer,
            act_func)

    def forward(self, x):
        res = self.conv(x)

        if self.resnet:
            res = res + x

        return res
    
class Up(nn.Module):
    """ Upscaling then conv """

    def __init__(self, in_channels, out_channels, activation='relu',  resnet=True):
        super().__init__()

        self.up_layer = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.up       = Conv(in_channels, out_channels, activation=activation, resnet=resnet)

    def forward(self, x):
        x = self.up_layer(x)
        return self.up(x)
    
class DConv(nn.Module):
    """ Double Conv Layer
    """
    def __init__(self, in_channels, out_channels, activation='relu', resnet=True):
        super().__init__()

        self.conv1 = Conv(in_channels, out_channels, activation=activation, resnet=resnet)
        self.conv2 = Conv(out_channels, out_channels, activation=activation, resnet=resnet)

    def forward(self, x):
        return self.conv2(self.conv1(x))


class Encoder(nn.Module):
    def __init__(self, in_channels=3,mid_act='LeakyReLU',resnet=True):
        super(Encoder,self).__init__()
        self.in_conv        = Conv(in_channels=in_channels,out_channels=32-in_channels,stride=1,activation=mid_act,resnet=resnet)
        self.down_32_64     = Conv(in_channels=32,out_channels=64,stride=2,activation=mid_act,resnet=resnet)
        self.down_64_64_1   = Conv(in_channels=64,out_channels=64,activation=mid_act,resnet=resnet)
        self.down_64_128    = Conv(64,128,stride=2,activation=mid_act,resnet=resnet)
        self.down_128_128_1 = Conv(128, 128,  activation=mid_act, resnet=resnet)
        self.down_128_256   = Conv(128, 256, stride=2, activation=mid_act, resnet=resnet)
        self.down_256_256_1 = Conv(256, 256, activation=mid_act, resnet=resnet)
        self.down_256_512   = Conv(256, 512, stride=2, activation=mid_act, resnet=resnet)
        self.down_512_512_1 = Conv(512, 512, activation=mid_act, resnet=resnet)
        self.down_512_512_2 = Conv(512, 512, activation=mid_act, resnet=resnet)
        self.down_512_512_3 = Conv(512, 512, activation=mid_act, resnet=resnet)

    def forward(self, x):
        x1 = self.in_conv(x)  # 32 x 512 x 512
        x1 = torch.cat((x, x1), dim=1)

        x2 = self.down_32_64(x1)
        x3 = self.down_64_64_1(x2)

        x4 = self.down_64_128(x3)
        x5 = self.down_128_128_1(x4)

        x6 = self.down_128_256(x5)
        x7 = self.down_256_256_1(x6)

        x8 = self.down_256_512(x7)
        x9 = self.down_512_512_1(x8)
        x10 = self.down_512_512_2(x9)
        x11 = self.down_512_512_3(x10)
        return x11, x10, x9, x8, x7, x6, x5, x4, x3, x2, x1

class Decoder(nn.Module):
    """ Up Stream Sequence """
    def __init__(self,
                 input_channel = 3,
                 out_channels=3,
                 mid_act='ReLU',
                 out_act='Sigmoid',
                 resnet = True):

        super(Decoder, self).__init__()

        self.up_16_16_1 = Conv(input_channel, 256, activation=mid_act, resnet=resnet)
        self.up_16_16_2 = Conv(768, 512, activation=mid_act, resnet=resnet)
        self.up_16_16_3 = Conv(1024, 512, activation=mid_act, resnet=resnet)

        self.up_16_32   = Up(1024, 256, activation=mid_act, resnet=resnet)
        self.up_32_32_1 = Conv(512, 256, activation=mid_act, resnet=resnet)

        self.up_32_64   = Up(512, 128, activation=mid_act, resnet=resnet)
        self.up_64_64_1 = Conv(256, 128, activation=mid_act, resnet=resnet)

        self.up_64_128    = Up(256, 64, activation=mid_act, resnet=resnet)
        self.up_128_128_1 = Conv(128, 64, activation=mid_act, resnet=resnet)

        self.up_128_256 = Up(128, 32, activation=mid_act, resnet=resnet)
        self.out_conv   = Conv(64, out_channels, activation=out_act)


    # def forward(self, x, latent):
    def forward(self, x, latent):
        x11, x10, x9, x8, x7, x6, x5, x4, x3, x2, x1 = x

        h,w = x10.shape[2:]
        # y = torch.concatenate(Light_direction,dim=1)       # 8 x 16 x 16
        y = latent

        y = self.up_16_16_1(y)  # 256 x 16 x 16

        y = torch.cat((x10, y), dim=1)  # 768 x 16 x 16
        y = self.up_16_16_2(y)  # 512 x 16 x 16


        y = torch.cat((x9, y), dim=1)  # 1024 x 16 x 16
        y = self.up_16_16_3(y)  # 512 x 16 x 16

        y = torch.cat((x8, y), dim=1)  # 1024 x 16 x 16
        y = self.up_16_32(y)  # 256 x 32 x 32

        y = torch.cat((x7, y), dim=1)
        y = self.up_32_32_1(y)  # 256 x 32 x 32

        y = torch.cat((x6, y), dim=1)
        y = self.up_32_64(y)

        y = torch.cat((x5, y), dim=1)
        y = self.up_64_64_1(y)  # 128 x 64 x 64

        y = torch.cat((x4, y), dim=1)
        y = self.up_64_128(y)

        y = torch.cat((x3, y), dim=1)
        y = self.up_128_128_1(y)  # 64 x 128 x 128

        y = torch.cat((x2, y), dim=1)
        y = self.up_128_256(y)  # 32 x 256 x 256

        y = torch.cat((x1, y), dim=1)
        y = self.out_conv(y)  # 3 x 256 x 256

        return y

class Shl_conv(nn.Module):
    def __init__(self, in_channels, out_channels, activation='relu', resnet=False):
        super(Shl_conv, self).__init__()
        normal_layer, activation_func = get_layer_info(out_channels, activation)
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=15, padding=7, bias=True),
            normal_layer,
            activation_func)
    def forward(self, x):
        return self.conv(x)

class Shl(nn.Module):
    def __init__(self, in_channels, out_channels, activation='relu', resnet=True):
        super(Shl, self).__init__()
        self.conv1 = Shl_conv(in_channels, out_channels, activation=activation, resnet=resnet)
        self.conv2 = Shl_conv(out_channels, out_channels, activation=activation, resnet=resnet)
        self.conv3 = Shl_conv(out_channels, out_channels, activation=activation, resnet=resnet)
        self.conv4 = Shl_conv(out_channels, out_channels, activation=activation, resnet=resnet)
        self.conv5 = Shl_conv(out_channels, out_channels, activation=activation, resnet=resnet)
    
    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x1)
        x3 = self.conv3(x2)
        x4 = self.conv4(x3)
        x5 = self.conv5(x4)
        return x5

        
class Self_Attention(nn.Module):
    def __init__(self, dim, dk, dv):
        super(Self_Attention,self).__init__()
        self.scale = dk ** -0.5
        self.q = nn.Linear(dim,dk)
        self.k = nn.Linear(dim,dk)
        self.v = nn.Linear(dim,dv)
    
    def forward(self, x):
        q = self.q(x)
        k = self.k(x)
        v = self.v(x)

        attn = (q @ k.transpose(-2,-1))* self.scale
        attn = attn.softmax(dim=-1)

        x = attn @ v

        return x

class Refine_Net(nn.Module):
    def __init__(self,in_channels=25,
                 out_channels=3,
                 mid_act='ReLU',
                 out_act_1='Tanh',
                 out_act_2='Tanh',
                 resnet=True
                 ):
        super(Refine_Net, self).__init__()
        self.light_Linear = nn.Sequential(
            nn.Linear(in_features=3, out_features=16),
            nn.LeakyReLU(),
            nn.Dropout(p=0.2),
            nn.Linear(in_features=16, out_features=16),
            nn.LeakyReLU(),
            nn.Dropout(p=0.2)
        )
        self.light_up = nn.Sequential(
            nn.ConvTranspose2d(1, 4, kernel_size=4, stride=2, padding=1),
            nn.ConvTranspose2d(4, 8, kernel_size=4, stride=2, padding=1),
            nn.ConvTranspose2d(8, 3, kernel_size=4, stride=2, padding=1),
            nn.LayerNorm([32, 32])
        )
        self.shadow_conv_32 = nn.Sequential(
            nn.Conv2d(in_channels=515, out_channels=512, kernel_size=1, padding=0),
            nn.Conv2d(in_channels=512, out_channels=1024, kernel_size=1, padding=0),
            nn.Conv2d(in_channels=1024, out_channels=512, kernel_size=1, padding=0),
            nn.LayerNorm([16, 16])
        )
        self.shading_conv_32 = nn.Sequential(
            nn.Conv2d(in_channels=515, out_channels=512, kernel_size=1, padding=0),
            nn.Conv2d(in_channels=512, out_channels=1024, kernel_size=1, padding=0),
            nn.Conv2d(in_channels=1024, out_channels=512, kernel_size=1, padding=0),
            nn.LayerNorm([16, 16])
        )
        self.encoder_shadow = Encoder(in_channels=8, mid_act=mid_act, resnet=resnet)
        self.decoder_shadow = Decoder(input_channel=512,out_channels=1, mid_act=mid_act, out_act='Sigmoid', resnet=resnet)
        self.encoder_shading = Encoder(in_channels=12, mid_act=mid_act, resnet=resnet)
        # self.decoder_shading = Decoder(input_channel=512,out_channels=3, mid_act=mid_act, out_act='Sigmoid', resnet=resnet)
        self.decoder_shading = Decoder(input_channel=512,out_channels=3, mid_act=mid_act, out_act='Tanh', resnet=resnet)
        self.out_conv = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=3, kernel_size=1, stride=1, padding=0),
            nn.Sigmoid()
        )

    def forward(self,light_direction,diffuse_shading,specular_shading,Vec_Shadow,Albedo,RGB_X):
        # Unet1
        x_0 = torch.cat([RGB_X,Albedo,Vec_Shadow,Vec_Shadow*diffuse_shading],axis=1)
        latent_0  = self.encoder_shadow(x_0)
        
        # 编码光照方向
        light_Linear = self.light_Linear(light_direction)
        light_direction = self.light_up(light_Linear.view(light_Linear.size(0), 1, 4, 4))
        light_direction = F.interpolate(light_direction, size=(latent_0[0].shape[-2], latent_0[0].shape[-1]), mode='bilinear', align_corners=True)

        latent_0_0 = self.shadow_conv_32(torch.cat([latent_0[0],light_direction],dim=1))
        output_shadow = self.decoder_shadow(latent_0, latent_0_0)
        
        x_1 = torch.cat([diffuse_shading,specular_shading,Albedo*diffuse_shading,RGB_X,output_shadow],dim=1)
        latent_1 = self.encoder_shading(x_1)
        latent_1_0 = self.shading_conv_32(torch.cat([latent_1[0],light_direction],dim=1))
        # output = self.out_conv(0.5*self.decoder_shading(latent_1,latent_1_0)+0.5*Albedo)
        # output = self.out_conv(self.decoder_shading(latent_1,latent_1_0))
        output = (self.decoder_shading(latent_1,latent_1_0)+1.0)/2
        return output,output_shadow

if __name__ == '__main__':
    device = torch.device('cuda:2' if torch.cuda.is_available() else 'cpu')
    B = 4
    # RAW DATA
    h,w,focus,p = 512,512,50,36
    mask_fg = torch.randn(B,1,512,512).to(device)
    mask_bg = torch.randn(B,1,512,512).to(device)
    img_lambertian = torch.randn(B,3,512,512).float().to(device)
    Albedo = torch.randn(B,3,512,512).float().to(device)
    Vec_Shadow = torch.randn(B,1,512,512).float().to(device)
    Light_direction = torch.randn(B, 3).float().to(device)
    model = Refine_Net(5,1).to(device)
    # model_structure(model)
    pred,pred_shadow = model(Light_direction,img_lambertian,Vec_Shadow,Albedo,mask_fg,mask_bg)
    import pdb;pdb.set_trace()