import torch
from attention_mechanisms.se_module import SELayer

x = torch.randn(2, 6, 512, 512)
attn = SELayer(6)
y = attn(x)
print(y.shape)
