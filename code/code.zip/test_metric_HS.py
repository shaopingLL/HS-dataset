import argparse
from tqdm import tqdm
import torch
import torchvision
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader,Dataset
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torchmetrics.image import StructuralSimilarityIndexMeasure as SSIM
from torchmetrics.image import PeakSignalNoiseRatio as PSNR
import os
from module.SRN_utrans import Refine_Net
from utils.dataset_p import MyDataset
from utils.RGB2HSV import RGB_HSV
import pdb
import cv2
import numpy as np
from module import Generator,Discriminator
import warnings
import lpips
import pickle
from loss.losses import *
import configs.config_HS_metric as config
warnings.filterwarnings("ignore")

DEBUG = True

rgb2hsv = RGB_HSV()

def Get_Dataset(pkl_path,data_path,start_index,end_index,batch_size,threshold=0.998):
    my_dataset = MyDataset(pkl_path=pkl_path,data_path=data_path,start_index=start_index,end_index=end_index,threshold=threshold)
    train_sampler = torch.utils.data.distributed.DistributedSampler(my_dataset,shuffle=False)
    if DEBUG:
        num_workers = 0
    else:
        num_workers = 4
    trainloader = torch.utils.data.DataLoader(my_dataset, 
        batch_size=batch_size, num_workers=num_workers, sampler=train_sampler)
    return trainloader

def param_update(data,param_opt,mode=None):
    pred = data['pred']
    x = data['x']
    gt = data['RGB_Image']
    h,w = config.img_size
    optimizer = param_opt['optimizer']
    L1_loss_func = param_opt['LOSS_FUNC']['L1_loss_func']
    Lpips_loss_func = param_opt['LOSS_FUNC']['Lpips_loss_func']
    grad_loss_func = param_opt['LOSS_FUNC']['grad_loss_func']
    ssim_metric = param_opt['METRIC_FUNC']['ssim_metric_func']
    psnr_metric = param_opt['METRIC_FUNC']['psnr_metric_func']
    L1_loss = 0
    L1_loss_hsv = 0
    Lpips_loss = 0
    ssim_loss = 0
    grad_Loss = 0
    for scale in [1,4]:
        pred_s = F.interpolate(pred,scale_factor=1/scale,mode='bilinear',align_corners=True)
        gt_s = F.interpolate(gt,scale_factor=1/scale,mode='bilinear',align_corners=True)
        L1_loss += L1_loss_func(pred_s,gt_s)
        ssim_loss += (1-ssim_metric(pred_s,gt_s))
        L1_loss_hsv += L1_loss_func(rgb2hsv.rgb_to_hsv(pred_s),rgb2hsv.rgb_to_hsv(gt_s))
        Lpips_loss += Lpips_loss_func(pred_s,gt_s).mean()
        grad_Loss += grad_loss_func(pred_s,gt_s)
    for scale in [16,64,256]:
        pred_s = F.interpolate(pred,scale_factor=1/scale,mode='bilinear',align_corners=True)
        gt_s = F.interpolate(gt,scale_factor=1/scale,mode='bilinear',align_corners=True)
        L1_loss += L1_loss_func(pred_s,gt_s)
        L1_loss_hsv += L1_loss_func(rgb2hsv.rgb_to_hsv(pred_s),rgb2hsv.rgb_to_hsv(gt_s))
        grad_Loss += grad_loss_func(pred_s,gt_s)
    loss = L1_loss + ssim_loss + L1_loss_hsv + Lpips_loss + grad_Loss
    LOSS = {'L1_loss':L1_loss.item(),
            'L1_loss_hsv':L1_loss_hsv.item(),
            'grad_loss':grad_Loss.item(),
            'ssim_loss':ssim_loss.item(),
            'Lpips_loss':Lpips_loss.item(),
            'loss':loss.item()
            }
    METRIC = {'ssim':ssim_metric(pred,gt).item(),
              'psnr':psnr_metric(pred,gt).item(),
              'lpips':Lpips_loss_func(pred,gt).mean().item()}
    if mode == 'train':
        optimizer.zero_grad() 
        loss.backward() 
        optimizer.step()  
    return LOSS,METRIC

def vis_result(TIME,result,local_rank,mode):
    step = TIME['step']
    pred = result['pred']
    input = result['input']
    RGB_Image = result['RGB_Image']
    if dist.get_rank() == 0:
        if mode == 'train':
            log_step = 10
        elif mode == 'eval':
            log_step = 1
        elif mode == 'metric':
            log_step = 1
        else:
            raise ValueError('mode should be train or test')
        if step % (1 if DEBUG else log_step) == 0:
            input_n = ((input).detach().cpu().numpy().transpose(0,2,3,1)*255).astype(np.uint8)
            pred_n = ((pred).detach().cpu().numpy().transpose(0,2,3,1)*255).astype(np.uint8)
            cv2.imwrite(f'metric_HS/img_{step}.png',pred_n[0])
            gt_n = ((RGB_Image).detach().cpu().numpy().transpose(0,2,3,1)*255).astype(np.uint8)
            compare_n = np.concatenate([input_n[0],pred_n[0],gt_n[0]],axis=1)
            cv2.imwrite(f'metric_HS/compare_{step}.png',compare_n)

def iter_data(loader,mode,opt,epoch):
    local_rank = opt['local_rank']
    model = opt['model']
    epoch = opt['epoch']
    forward_size = opt['size']
    metrics = {'ssim':0,
               'psnr':0,
               'lpips':0,
               'MPS':0}
    for i,sample_dict in enumerate(tqdm(loader)):
        RGB_Image = F.interpolate(sample_dict['RGB_Image'].float(), size=forward_size, mode='bilinear', align_corners=False).to(local_rank)
        x = F.interpolate(sample_dict['RGB_Image_x'].float(), size=forward_size, mode='bilinear', align_corners=False).to(local_rank)
        Base_color = F.interpolate(sample_dict['Base_color'].float(), size=forward_size, mode='bilinear', align_corners=False).to(local_rank)
        diffuse_shading = F.interpolate(sample_dict['diffuse_shading'].float(), size=forward_size, mode='bilinear', align_corners=False).to(local_rank)
        specular_shading = F.interpolate(sample_dict['specular_shading'].float(), size=forward_size, mode='bilinear', align_corners=False).to(local_rank)
        Vec_Shadow = F.interpolate(sample_dict['Vec_Shadow'].float(), size=forward_size, mode='bilinear', align_corners=False).to(local_rank)
        light_direction = sample_dict['light_direction'].float().to(local_rank)
        pred,pred_shadow = model(light_direction,diffuse_shading,specular_shading,Vec_Shadow,Base_color,x)
        data = {'pred':pred,
                'x':x,
                'RGB_Image':RGB_Image}
        param_opt = {'optimizer':opt['optimizer'],
                     'LOSS_FUNC':opt['LOSS_FUNC'],
                     'METRIC_FUNC':opt['METRIC_FUNC']}
        LOSS,METRIC = param_update(data,param_opt,mode)
        TIME = {'epoch':epoch,
                'step':i,
                'total_step':len(loader)*epoch+i}
        result = {'LOSS':LOSS,
                  'METRIC':METRIC,
                  'pred_shadow':pred_shadow,
                  'pred':pred,
                  'RGB_Image':RGB_Image,
                  'base_color':Base_color,
                  'input':x,
                  'Vec_Shadow':Vec_Shadow,
                  'diffuse_shading':diffuse_shading,
                  'specular_shading':specular_shading,
                  'light_direction':light_direction}
        vis_result(TIME,result,local_rank,mode)
        metrics['ssim'] += METRIC['ssim']
        metrics['psnr'] += METRIC['psnr']
        metrics['lpips'] += METRIC['lpips']
    metrics['ssim'] /= len(loader)
    metrics['psnr'] /= len(loader)
    metrics['lpips'] /= len(loader)
    metrics['MPS'] = 0.5*(metrics['ssim'] + (1-metrics['lpips']))
    return metrics

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--local_rank", default=-1, type=int)
    FLAGS = parser.parse_args()
    local_rank = int(os.getenv('LOCAL_RANK', -1))
    print('local_rank:', local_rank)
    torch.cuda.set_device(local_rank)
    dist.init_process_group(backend='nccl')
    pkl_path = config.pkl_path
    data_path = config.data_path
    if DEBUG:
        batch_size = config.debug_batch_size
    else:
        batch_size = config.train_batch_size
    threshold = config.threshold
    start_index,end_index = config.train_start,config.train_end
    trainloader = Get_Dataset(pkl_path,data_path,start_index,end_index,batch_size,threshold)
    start_index,end_index = config.eval_start,config.eval_end
    testloader = Get_Dataset(pkl_path,data_path,start_index,end_index,1,threshold)

    print('### 2. 初始化我们的模型、数据、各种配置  ####')
    print('local_rank:', local_rank)
    model = Refine_Net().to(local_rank)
    ckpt_path = config.ckpt_path
    if dist.get_rank() == 0 and ckpt_path is not None:
        model.load_state_dict(torch.load(ckpt_path))
    model = DDP(model, device_ids=[local_rank], output_device=local_rank,broadcast_buffers=False,find_unused_parameters=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=config.lr)
    L1_loss_func = nn.L1Loss().to(local_rank)
    Lpips_loss_func = lpips.LPIPS(net='alex').to(local_rank)
    grad_loss_func = GradientLoss().to(local_rank)
    ssim_metric_func = SSIM(data_range=1.0).to(local_rank)
    psnr_metric_func = PSNR().to(local_rank)
    LOSS_FUNC = {'L1_loss_func':L1_loss_func,
                  'Lpips_loss_func':Lpips_loss_func,
                  'grad_loss_func':grad_loss_func,}
    METRIC_FUNC = {'ssim_metric_func':ssim_metric_func,
                   'psnr_metric_func':psnr_metric_func}
    model.train()
    iterator = [0]
    for epoch in iterator:
        testloader.sampler.set_epoch(epoch)
        opt = {'local_rank':local_rank,
               'model':model,
               'epoch':epoch,
               'size':config.img_size,
               'optimizer':optimizer,
               'LOSS_FUNC':LOSS_FUNC,
               'METRIC_FUNC':METRIC_FUNC
               }
        eval_metrics = iter_data(loader=testloader,mode='metric',opt=opt,epoch=epoch)
        print(f'\neval_metrics \n{eval_metrics}')
if '__main__' == __name__:
    main()